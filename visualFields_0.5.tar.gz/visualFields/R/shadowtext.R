shadowtext <- function( x, y = NULL, labels,
                        col = "white", bg = "black",
                        theta = seq( 0, 2 * pi, length.out = 50 ),
                        r = 0.1 ) {
  # function found in
  # http://stackoverflow.com/questions/25631216/r-is-there-any-way-to-put-border-shadow-or-buffer-around-text-labels-en-r-plot
  # credited to Greg Snow. Link to Greg Snow's site does not work
  xy <- xy.coords( x , y )
  xo <- r * strwidth( "A" )
  yo <- r * strheight( "A" )
  
  # draw background text with small shift in x and y in background colour
  for ( i in theta ) {
    text( xy$x + cos( i ) * xo, xy$y + sin( i ) * yo, labels, col = bg )
  }
  # draw actual text in exact xy position in foreground colour
  text( xy$x, xy$y, labels, col = col )
}